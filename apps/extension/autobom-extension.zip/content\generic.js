// src/content/generic.ts
var SUPPLIER_RULES = [
  { pattern: /xometry\./i, name: "Xometry", site: "xometry" },
  { pattern: /leroymerlin\./i, name: "Leroy Merlin", site: "leroymerlin" },
  { pattern: /bricovis\./i, name: "Bricovis", site: "bricovis" },
  { pattern: /123roulements\./i, name: "123Roulements", site: "123roulements" },
  { pattern: /norelem\./i, name: "Norelem", site: "norelem" },
  { pattern: /aliexpress\./i, name: "AliExpress", site: "aliexpress" },
  { pattern: /alibaba\./i, name: "Alibaba", site: "alibaba" },
  { pattern: /ebay\./i, name: "eBay", site: "ebay" },
  { pattern: /leboncoin\./i, name: "Leboncoin", site: "leboncoin" },
  { pattern: /manomano\./i, name: "ManoMano", site: "manomano" },
  { pattern: /conrad\./i, name: "Conrad", site: "conrad" },
  { pattern: /farnell\.|element14\./i, name: "Farnell", site: "farnell" },
  { pattern: /mouser\./i, name: "Mouser", site: "mouser" },
  { pattern: /digikey\./i, name: "Digi-Key", site: "digikey" },
  { pattern: /wurth\./i, name: "W\xFCrth", site: "wurth" },
  { pattern: /bricozor\./i, name: "Bricozor", site: "bricozor" },
  { pattern: /bricodepot\./i, name: "Brico D\xE9p\xF4t", site: "bricodepot" },
  { pattern: /castorama\./i, name: "Castorama", site: "castorama" },
  { pattern: /igus\./i, name: "igus", site: "igus" },
  { pattern: /festo\./i, name: "Festo", site: "festo" },
  { pattern: /smc\./i, name: "SMC", site: "smc" }
];
function text(selector) {
  return document.querySelector(selector)?.innerText?.trim() || void 0;
}
function meta(selector) {
  return document.querySelector(selector)?.content?.trim() || void 0;
}
function parsePrice(raw) {
  if (raw == null) return void 0;
  const value = String(raw).match(/[\d\s.,]+/)?.[0]?.replace(/\s/g, "").replace(",", ".");
  if (!value) return void 0;
  const parsed = Number.parseFloat(value);
  return Number.isFinite(parsed) ? parsed : void 0;
}
function jsonLdProducts() {
  const scripts = Array.from(document.querySelectorAll('script[type="application/ld+json"]'));
  const products = [];
  for (const script of scripts) {
    try {
      const parsed = JSON.parse(script.textContent ?? "");
      const nodes = Array.isArray(parsed) ? parsed : parsed?.["@graph"] ?? [parsed];
      for (const node of nodes) {
        const type = node?.["@type"];
        const types = Array.isArray(type) ? type : [type];
        if (types.some((t) => String(t).toLowerCase() === "product")) products.push(node);
      }
    } catch {
    }
  }
  return products;
}
function firstOffer(product) {
  const offers = product?.offers;
  return Array.isArray(offers) ? offers[0] : offers;
}
function supplierFromHost() {
  const host = location.hostname;
  const rule = SUPPLIER_RULES.find((r) => r.pattern.test(host));
  if (rule) return rule;
  const clean = host.replace(/^www\./, "").split(".")[0];
  const name = clean.charAt(0).toUpperCase() + clean.slice(1);
  return { name, site: "generic" };
}
function hasBuyIntent() {
  const candidates = Array.from(document.querySelectorAll("button, a, input[type='submit']"));
  return candidates.some((el) => /ajouter|panier|acheter|commander|add to cart|buy now|add basket|checkout/i.test(el.innerText || el.getAttribute("value") || el.getAttribute("aria-label") || ""));
}
function productScore(product) {
  let score = 0;
  if (product) score += 4;
  if (document.querySelector("h1")) score += 1;
  if (extractPrice(product) != null) score += 2;
  if (extractRef(product)) score += 1;
  if (hasBuyIntent()) score += 2;
  if (/\/((product|produit|item|dp|p|annonces?|catalogue|shop)\/|itm\/)/i.test(location.pathname)) score += 1;
  return score;
}
function extractTitle(product) {
  return product?.name || meta('meta[property="og:title"]') || meta('meta[name="twitter:title"]') || text("h1");
}
function extractRef(product) {
  return product?.sku || product?.mpn || text('[itemprop="sku"], [class*="sku"], [class*="Sku"], [class*="reference"], [class*="Reference"], [data-testid*="sku"], [data-testid*="ref"]')?.replace(/^(sku|réf\.?|ref\.?|reference)\s*:?\s*/i, "");
}
function extractPrice(product) {
  const offerPrice = parsePrice(firstOffer(product)?.price);
  if (offerPrice != null) return offerPrice;
  return parsePrice(
    document.querySelector('[itemprop="price"], [class*="price"], [class*="Price"], [data-testid*="price"]')?.getAttribute("content") || text('[itemprop="price"], [class*="price"], [class*="Price"], [data-testid*="price"]')
  );
}
function extract() {
  const product = jsonLdProducts()[0];
  if (productScore(product) < 4) return null;
  const designation = extractTitle(product);
  if (!designation) return null;
  const supplier = supplierFromHost();
  return {
    designation,
    supplierRef: extractRef(product),
    productUrl: location.href,
    unitPriceHT: extractPrice(product),
    supplierName: supplier.name,
    site: supplier.site
  };
}
function injectButton() {
  if (document.getElementById("autobom-capture-btn")) return;
  if (!extract()) return;
  const btn = document.createElement("button");
  btn.id = "autobom-capture-btn";
  btn.textContent = "\u{1F4CB} Envoyer vers AutoBOM";
  Object.assign(btn.style, {
    position: "fixed",
    bottom: "24px",
    right: "24px",
    zIndex: "99999",
    background: "#2563eb",
    color: "#fff",
    border: "none",
    borderRadius: "8px",
    padding: "10px 16px",
    fontSize: "13px",
    fontWeight: "600",
    cursor: "pointer",
    boxShadow: "0 4px 12px rgba(0,0,0,.25)"
  });
  btn.addEventListener("click", () => {
    const data = extract();
    if (!data) {
      alert("AutoBOM : cette page ne ressemble plus \xE0 une page produit.");
      return;
    }
    chrome.runtime.sendMessage({ type: "AUTOBOM_CAPTURE", payload: data });
    btn.textContent = "\u2713 Captur\xE9 !";
    btn.style.background = "#16a34a";
    setTimeout(() => {
      btn.textContent = "\u{1F4CB} Envoyer vers AutoBOM";
      btn.style.background = "#2563eb";
    }, 2e3);
  });
  document.body.appendChild(btn);
}
function scheduleInject() {
  setTimeout(injectButton, 700);
  setTimeout(injectButton, 2e3);
}
if (document.readyState === "loading") {
  document.addEventListener("DOMContentLoaded", scheduleInject);
} else {
  scheduleInject();
}
new MutationObserver(() => injectButton()).observe(document.documentElement, { childList: true, subtree: true });
