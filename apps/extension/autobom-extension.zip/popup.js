// src/popup/popup.ts
var DEFAULT_BASE = "https://auto-bom-web-soh3.vercel.app";
var viewLoading = document.getElementById("view-loading");
var viewProduct = document.getElementById("view-product");
var viewEmpty = document.getElementById("view-empty");
var viewSettings = document.getElementById("view-settings");
var capName = document.getElementById("cap-name");
var capSupplier = document.getElementById("cap-supplier");
var capRef = document.getElementById("cap-ref");
var capPrice = document.getElementById("cap-price");
var btnSend = document.getElementById("btn-send");
var btnSettings = document.getElementById("btn-settings-toggle");
var inputBase = document.getElementById("input-base");
var btnSave = document.getElementById("btn-save-settings");
var btnOpenApp = document.getElementById("btn-open-app");
function show(el) {
  el.classList.remove("hidden");
}
function hide(el) {
  el.classList.add("hidden");
}
function hideAll() {
  hide(viewLoading);
  hide(viewProduct);
  hide(viewEmpty);
}
function getBase() {
  return new Promise((res) => {
    chrome.storage.local.get("autobom_base", (r) => {
      res(r.autobom_base ?? DEFAULT_BASE);
    });
  });
}
function extractFromPage() {
  const url = location.href;
  const host = location.hostname.replace(/^www\./, "");
  function priceFromText(text) {
    if (!text) return void 0;
    const m = text.replace(/\s/g, "").match(/(\d+[.,]?\d*)/);
    if (!m) return void 0;
    const n = parseFloat(m[1].replace(",", "."));
    return isNaN(n) || n <= 0 || n > 1e6 ? void 0 : n;
  }
  if (host.includes("amazon.")) {
    const designation2 = document.getElementById("productTitle")?.innerText?.trim();
    if (!designation2) return null;
    const asin = document.querySelector("[data-asin]")?.dataset?.asin || document.querySelector("[data-csa-c-asin]")?.dataset?.csaCAsin || void 0;
    const whole = document.querySelector(".a-price-whole")?.textContent?.replace(/[^\d]/g, "");
    const frac = document.querySelector(".a-price-fraction")?.textContent?.replace(/[^\d]/g, "");
    let price2;
    if (whole) {
      const ttc = parseFloat(`${whole}.${frac ?? "00"}`);
      price2 = ttc ? Math.round(ttc / 1.2 * 100) / 100 : void 0;
    }
    return { designation: designation2, supplierRef: asin, productUrl: url, unitPriceHT: price2, supplierName: "Amazon" };
  }
  if (host.includes("aliexpress.")) {
    const titleEl = document.querySelector('h1[data-pl="product-title"]') || document.querySelector(".pdp-info h1") || document.querySelector("h1");
    const designation2 = titleEl?.textContent?.trim();
    if (!designation2 || designation2.length < 3) return null;
    const priceEl2 = document.querySelector(".product-price-value") || document.querySelector('[class*="price-default"]') || document.querySelector('[class*="price"]');
    const price2 = priceFromText(priceEl2?.textContent);
    return { designation: designation2, productUrl: url, unitPriceHT: price2, supplierName: "AliExpress" };
  }
  if (host.includes("tolery.")) {
    const designation2 = document.querySelector("h1")?.textContent?.trim();
    if (!designation2) return null;
    const refEl = document.querySelector('[class*="reference" i]');
    const supplierRef = refEl?.textContent?.replace(/r[ée]f[ée]rence\s*:?\s*/i, "").trim() || void 0;
    const priceEl2 = document.querySelector('[class*="price" i]');
    const price2 = priceFromText(priceEl2?.textContent);
    return { designation: designation2, supplierRef, productUrl: url, unitPriceHT: price2, supplierName: "Tolery" };
  }
  const ogTitle = document.querySelector('meta[property="og:title"]')?.getAttribute("content")?.trim();
  const h1 = document.querySelector("h1")?.textContent?.trim();
  const designation = ogTitle || h1;
  if (!designation || designation.length < 3) return null;
  const priceEl = document.querySelector('[itemprop="price"]') || document.querySelector('meta[property="product:price:amount"]') || document.querySelector('[class*="price" i]');
  const priceContent = priceEl?.getAttribute("content") ?? priceEl?.textContent ?? null;
  const price = priceFromText(priceContent);
  const supplierName = host.split(".")[0].replace(/^\w/, (c) => c.toUpperCase());
  return { designation, productUrl: url, unitPriceHT: price, supplierName };
}
async function extractCurrentTab() {
  const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
  if (!tab?.id) return null;
  if (!tab.url || !/^https?:/.test(tab.url)) return null;
  try {
    const results = await chrome.scripting.executeScript({
      target: { tabId: tab.id },
      func: extractFromPage
    });
    return results[0]?.result ?? null;
  } catch (err) {
    console.warn("[AutoBOM] extraction failed:", err);
    return null;
  }
}
function encodeProduct(p) {
  const json = JSON.stringify(p);
  return btoa(unescape(encodeURIComponent(json))).replace(/\+/g, "-").replace(/\//g, "_").replace(/=+$/, "");
}
function renderProduct(p) {
  capName.textContent = p.designation;
  capSupplier.textContent = p.supplierName;
  capRef.textContent = p.supplierRef ? `R\xE9f : ${p.supplierRef}` : "";
  if (p.unitPriceHT) {
    capPrice.textContent = `${p.unitPriceHT.toFixed(2)} \u20AC HT`;
    show(capPrice);
  } else {
    hide(capPrice);
  }
  hideAll();
  show(viewProduct);
}
function renderEmpty() {
  hideAll();
  show(viewEmpty);
}
async function init() {
  const base = await getBase();
  inputBase.value = base;
  hideAll();
  show(viewLoading);
  const product = await extractCurrentTab();
  if (!product) {
    renderEmpty();
    return;
  }
  renderProduct(product);
  btnSend.addEventListener("click", async () => {
    const baseNow = await getBase();
    const url = `${baseNow}/capture?p=${encodeProduct(product)}`;
    await chrome.tabs.create({ url });
    window.close();
  });
}
btnSettings.addEventListener("click", (e) => {
  e.preventDefault();
  viewSettings.classList.toggle("hidden");
});
btnOpenApp.addEventListener("click", async () => {
  const base = await getBase();
  await chrome.tabs.create({ url: base });
  window.close();
});
btnSave.addEventListener("click", () => {
  const base = inputBase.value.trim().replace(/\/$/, "");
  chrome.storage.local.set({ autobom_base: base }, () => {
    btnSave.textContent = "Enregistr\xE9 \u2713";
    setTimeout(() => {
      btnSave.textContent = "Enregistrer l'URL";
    }, 1500);
  });
});
init();
