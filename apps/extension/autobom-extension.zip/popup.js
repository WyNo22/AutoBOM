// src/popup/popup.ts
var viewCapture = document.getElementById("view-capture");
var viewEmpty = document.getElementById("view-empty");
var viewLogin = document.getElementById("view-login");
var viewSettings = document.getElementById("view-settings");
var capName = document.getElementById("cap-name");
var capSupplier = document.getElementById("cap-supplier");
var capRef = document.getElementById("cap-ref");
var capPrice = document.getElementById("cap-price");
var bomSelect = document.getElementById("bom-select");
var btnSend = document.getElementById("btn-send");
var btnDiscard = document.getElementById("btn-discard");
var sendStatus = document.getElementById("send-status");
var btnSettingsToggle = document.getElementById("btn-settings-toggle");
var inputBase = document.getElementById("input-base");
var btnSaveSettings = document.getElementById("btn-save-settings");
var btnLogin = document.getElementById("btn-login");
var btnLoginMain = document.getElementById("btn-login-main");
var btnRefreshSession = document.getElementById("btn-refresh-session");
var connStatus = document.getElementById("conn-status");
var connText = document.getElementById("conn-text");
function show(el) {
  el.classList.remove("hidden");
}
function hide(el) {
  el.classList.add("hidden");
}
function hideMainViews() {
  hide(viewCapture);
  hide(viewEmpty);
  hide(viewLogin);
}
function setStatus(msg, type) {
  sendStatus.textContent = msg;
  sendStatus.className = `status ${type}`;
  show(sendStatus);
}
function getBase() {
  return new Promise((res) => {
    chrome.storage.local.get("autobom_base", (r) => {
      res(r.autobom_base ?? "https://auto-bom-web-soh3.vercel.app");
    });
  });
}
async function isConnected(base) {
  try {
    const r = await fetch(`${base}/api/me/boms`, { credentials: "include" });
    return r.ok;
  } catch {
    return false;
  }
}
async function openLogin() {
  const base = await getBase();
  chrome.tabs.create({ url: `${base}/login` });
}
async function loadBoms(base) {
  try {
    const r = await fetch(`${base}/api/me/boms`, { credentials: "include" });
    if (!r.ok) throw new Error("auth");
    const { boms } = await r.json();
    bomSelect.innerHTML = "";
    if (!boms.length) {
      bomSelect.innerHTML = "<option value=''>Aucune BOM trouv\xE9e</option>";
      return;
    }
    const byProject = /* @__PURE__ */ new Map();
    for (const b of boms) {
      if (!byProject.has(b.projectId))
        byProject.set(b.projectId, { name: b.projectName, boms: [] });
      byProject.get(b.projectId).boms.push(b);
    }
    for (const [, proj] of byProject) {
      const grp = document.createElement("optgroup");
      grp.label = proj.name;
      for (const b of proj.boms) {
        const opt = document.createElement("option");
        opt.value = b.bomId;
        opt.textContent = `${b.bomName} (${b.bomStatus})`;
        grp.appendChild(opt);
      }
      bomSelect.appendChild(grp);
    }
  } catch {
    bomSelect.innerHTML = "<option value=''>Erreur \u2014 connect\xE9 \xE0 AutoBOM ?</option>";
  }
}
async function init() {
  const base = await getBase();
  inputBase.value = base;
  const connected = await isConnected(base);
  if (!connected) {
    hideMainViews();
    show(viewLogin);
    return;
  }
  chrome.storage.local.get("autobom_pending", async (res) => {
    const raw = res.autobom_pending;
    if (!raw) {
      hideMainViews();
      show(viewEmpty);
      return;
    }
    let pending;
    try {
      pending = JSON.parse(raw);
    } catch {
      hideMainViews();
      show(viewEmpty);
      return;
    }
    const p = pending.payload;
    capName.textContent = p.designation;
    capSupplier.textContent = p.supplierName;
    capRef.textContent = p.supplierRef ? `R\xE9f: ${p.supplierRef}` : "";
    if (p.unitPriceHT) {
      capPrice.textContent = `${p.unitPriceHT.toFixed(2)} \u20AC HT`;
    } else {
      capPrice.classList.add("hidden");
    }
    hideMainViews();
    show(viewCapture);
    await loadBoms(base);
    if (pending.bomId) bomSelect.value = pending.bomId;
    btnSend.addEventListener("click", async () => {
      const bomId = bomSelect.value;
      if (!bomId) {
        setStatus("S\xE9lectionne une BOM", "err");
        return;
      }
      btnSend.disabled = true;
      btnSend.textContent = "Envoi\u2026";
      chrome.storage.local.set({ autobom_pending: JSON.stringify({ payload: p, bomId }) });
      chrome.runtime.sendMessage({ type: "AUTOBOM_SEND", payload: p, bomId }, (res2) => {
        if (res2?.ok) {
          setStatus("\u2713 Ligne ajout\xE9e \xE0 la BOM !", "ok");
          btnSend.textContent = "Envoy\xE9 !";
          setTimeout(() => window.close(), 1200);
        } else {
          setStatus("Erreur lors de l'envoi. V\xE9rifie la connexion AUTBOM.", "err");
          btnSend.disabled = false;
          btnSend.textContent = "Envoyer dans la BOM";
        }
      });
    });
    btnDiscard.addEventListener("click", () => {
      chrome.runtime.sendMessage({ type: "AUTOBOM_CLEAR" });
      window.close();
    });
  });
}
async function checkConnection(base) {
  try {
    const r = await fetch(`${base}/api/me/boms`, { credentials: "include" });
    if (r.ok) {
      connStatus.className = "conn-badge ok";
      connText.textContent = "Connect\xE9 \xE0 AutoBOM";
    } else {
      connStatus.className = "conn-badge err";
      connText.textContent = "Non connect\xE9 \u2014 clique le bouton ci-dessous";
    }
  } catch {
    connStatus.className = "conn-badge err";
    connText.textContent = "Serveur inaccessible";
  }
}
btnSettingsToggle.addEventListener("click", async (e) => {
  e.preventDefault();
  viewSettings.classList.toggle("hidden");
  if (!viewSettings.classList.contains("hidden")) {
    const base = await getBase();
    checkConnection(base);
  }
});
btnLogin.addEventListener("click", async () => {
  openLogin();
});
btnLoginMain.addEventListener("click", () => {
  openLogin();
});
btnRefreshSession.addEventListener("click", () => {
  window.location.reload();
});
btnSaveSettings.addEventListener("click", () => {
  const base = inputBase.value.trim().replace(/\/$/, "");
  chrome.storage.local.set({ autobom_base: base }, () => {
    btnSaveSettings.textContent = "Enregistr\xE9 \u2713";
    setTimeout(() => {
      btnSaveSettings.textContent = "Enregistrer l'URL";
    }, 1500);
  });
});
init();
