// src/background/index.ts
var DEFAULT_BASE = "https://auto-bom-web-soh3.vercel.app";
async function getSettings() {
  return new Promise((resolve) => {
    chrome.storage.local.get(["autobom_base", "autobom_token"], (res) => {
      resolve({
        baseUrl: res.autobom_base ?? DEFAULT_BASE,
        token: res.autobom_token ?? ""
      });
    });
  });
}
function storePending(payload, bomId) {
  chrome.storage.local.set({ autobom_pending: JSON.stringify({ payload, bomId }) });
}
async function sendCapture(payload, bomId) {
  const { baseUrl, token } = await getSettings();
  try {
    const res = await fetch(`${baseUrl}/api/boms/${bomId}/capture`, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        ...token ? { Authorization: `Bearer ${token}` } : {}
      },
      credentials: "include",
      body: JSON.stringify({
        designation: payload.designation,
        supplierRef: payload.supplierRef,
        productUrl: payload.productUrl,
        unitPriceHT: payload.unitPriceHT,
        qty: payload.qty ?? 1,
        notes: payload.notes,
        supplierName: payload.supplierName
      })
    });
    return res.ok;
  } catch {
    return false;
  }
}
chrome.runtime.onMessage.addListener((msg, _sender, sendResponse) => {
  if (msg.type === "AUTOBOM_CAPTURE") {
    const payload = msg.payload;
    storePending(payload);
    chrome.action.setBadgeText({ text: "1" });
    chrome.action.setBadgeBackgroundColor({ color: "#2563eb" });
    sendResponse({ ok: true });
  }
  if (msg.type === "AUTOBOM_SEND") {
    const { payload, bomId } = msg;
    sendCapture(payload, bomId).then((ok) => {
      if (ok) {
        chrome.storage.local.remove("autobom_pending");
        chrome.action.setBadgeText({ text: "" });
      }
      sendResponse({ ok });
    });
    return true;
  }
  if (msg.type === "AUTOBOM_CLEAR") {
    chrome.storage.local.remove("autobom_pending");
    chrome.action.setBadgeText({ text: "" });
    sendResponse({ ok: true });
  }
});
console.log("[AutoBOM] background worker loaded");
