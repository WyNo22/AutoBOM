// src/background/index.ts
console.log("[AutoBOM] background worker loaded");
