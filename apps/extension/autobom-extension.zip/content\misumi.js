// src/content/misumi.ts
function extract() {
  const designation = document.querySelector(".product-name, h1.pdp-title, [class*='ProductName']")?.innerText?.trim() ?? document.querySelector("h1")?.innerText?.trim();
  if (!designation) return null;
  const supplierRef = document.querySelector(".pn-input, [class*='part-number'], [id*='partNumber']")?.innerText?.replace(/[^\w-]/g, "").trim() || new URLSearchParams(location.search).get("pn") || void 0;
  const priceEl = document.querySelector(
    "[class*='price-value'], [class*='unit-price'], .price .amount"
  );
  let unitPriceHT;
  if (priceEl) {
    const m = priceEl.innerText.match(/([\d\s.,]+)/);
    if (m) unitPriceHT = parseFloat(m[1].replace(/\s/g, "").replace(",", ".")) || void 0;
  }
  return { designation, supplierRef, productUrl: location.href, unitPriceHT };
}
function injectButton() {
  if (document.getElementById("autobom-capture-btn")) return;
  const btn = document.createElement("button");
  btn.id = "autobom-capture-btn";
  btn.textContent = "\u{1F4CB} Envoyer vers AutoBOM";
  Object.assign(btn.style, {
    position: "fixed",
    bottom: "24px",
    right: "24px",
    zIndex: "99999",
    background: "#2563eb",
    color: "#fff",
    border: "none",
    borderRadius: "8px",
    padding: "10px 16px",
    fontSize: "13px",
    fontWeight: "600",
    cursor: "pointer",
    boxShadow: "0 4px 12px rgba(0,0,0,.25)"
  });
  btn.addEventListener("click", () => {
    const data = extract();
    if (!data) {
      alert("AutoBOM : impossible d'extraire les donn\xE9es produit.");
      return;
    }
    const payload = { ...data, supplierName: "Misumi", site: "misumi" };
    chrome.runtime.sendMessage({ type: "AUTOBOM_CAPTURE", payload });
    btn.textContent = "\u2713 Captur\xE9 !";
    btn.style.background = "#16a34a";
    setTimeout(() => {
      btn.textContent = "\u{1F4CB} Envoyer vers AutoBOM";
      btn.style.background = "#2563eb";
    }, 2e3);
  });
  document.body.appendChild(btn);
}
if (document.readyState === "loading") {
  document.addEventListener("DOMContentLoaded", injectButton);
} else {
  injectButton();
}
